import React from 'react';

export const NotFoundPage = () => (
    <h1>Make sure you typed in the url correctly!</h1>
);